import React from "react";

const Marquee = () => {
  return (
   
    <div className="marquee_text">
      <div className="marquee">
        <p className="stop-on-hover">
          মুসলিম সাহিত্য সংসদ গ্রন্থাগারে আপনাদের সকলকে জানাই স্বাগত , &nbsp; &nbsp;&nbsp;
         " আসুন শুরু করি সবাই মিলে একসাথে লেখা, যাতে সবার মনের মাঝে একটা নতুন দাগ
          কেটে যায় আজকের বাংলা"! &nbsp;&nbsp;&nbsp; কোনো লেখক বা লেখিকা যদি তাদের সুন্দর লেখা  আমাদের এই ওয়েবসাইট-এ আপলোড করতে চান তাহলে আমাদের মেইল করুন -
          kmss1936@gmail.com
        </p>
      </div>
    </div>
   
  );
};

export default Marquee;
