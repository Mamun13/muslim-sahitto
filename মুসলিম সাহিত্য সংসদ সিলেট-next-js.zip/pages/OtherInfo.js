import React from "react";
import Topbanner from "../components/Modules/Topbanner";
import BackToTop from "../components/Modules/BackToTop";
import Otherinformation from "../components/Modules/OtherInformation";

const other_info = () => {
  return (
    <>
      <Topbanner />
      <Otherinformation />
      <BackToTop />
    </>
  );
};
export default other_info;
